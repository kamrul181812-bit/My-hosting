// Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyD5gpqaMxgVcFgTXnUI5agJeq0E88i3Fdk",
    authDomain: "my-hosting-d5bdf.firebaseapp.com",
    projectId: "my-hosting-d5bdf",
    storageBucket: "my-hosting-d5bdf.firebasestorage.app",
    messagingSenderId: "773336711456",
    appId: "1:773336711456:web:099ab86b732db6818a9745"
};

// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
const auth = firebase.getAuth(app);
const db = firebase.getFirestore(app);

// State Management
let currentUser = null;
let botFiles = { bot: null, req: null };
let botStatus = 'stopped';
let userData = null;

// Initialize the application
export function initializeApp() {
    renderAuthScreen();
    setupAuthListener();
}

// Auth State Listener
function setupAuthListener() {
    firebase.onAuthStateChanged(auth, async (user) => {
        currentUser = user;
        if (user) {
            await loadUserData();
            renderDashboard();
            setupRealtimeListener();
        } else {
            renderAuthScreen();
        }
    });
}

// Load user data from Firestore
async function loadUserData() {
    try {
        const userDoc = await firebase.getDoc(firebase.doc(db, 'users', currentUser.uid));
        if (userDoc.exists()) {
            userData = userDoc.data();
            
            // Load bot files if exist
            if (userData.botFiles) {
                botFiles = userData.botFiles;
            }
            
            // Set bot status
            if (userData.botState) {
                botStatus = userData.botState;
            }
        } else {
            // Create user document if doesn't exist
            await firebase.setDoc(firebase.doc(db, 'users', currentUser.uid), {
                email: currentUser.email,
                balance: 100.00,
                createdAt: firebase.serverTimestamp(),
                botState: 'stopped',
                botFiles: {},
                lastDeployed: null,
                netlifyUrl: null,
                githubRepo: null
            });
            
            userData = {
                email: currentUser.email,
                balance: 100.00,
                botState: 'stopped',
                botFiles: {}
            };
        }
    } catch (error) {
        console.error('Error loading user data:', error);
        addToConsole(`Error: ${error.message}`, 'error');
    }
}

// Render Functions
function renderAuthScreen() {
    const app = document.getElementById('app');
    app.innerHTML = `
        <div class="max-w-md mx-auto mt-16">
            <div class="bg-gray-800 rounded-xl shadow-2xl p-8">
                <div class="text-center mb-8">
                    <i class="fas fa-robot text-5xl text-blue-500 mb-4"></i>
                    <h1 class="text-3xl font-bold">Python Bot Hosting</h1>
                    <p class="text-gray-400 mt-2">Deploy your Python bots to Netlify</p>
                </div>
                
                <div id="login-form">
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium mb-2">Email</label>
                            <input type="email" id="email" 
                                   class="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                   placeholder="you@example.com">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium mb-2">Password</label>
                            <input type="password" id="password" 
                                   class="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                   placeholder="••••••••">
                        </div>
                        
                        <button onclick="window.handleLogin()" 
                                class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition duration-200">
                            <i class="fas fa-sign-in-alt mr-2"></i> Login
                        </button>
                        
                        <div class="text-center">
                            <p class="text-gray-400">Don't have an account? 
                                <button onclick="window.showSignup()" class="text-blue-400 hover:text-blue-300 font-medium">
                                    Sign up here
                                </button>
                            </p>
                        </div>
                        
                        <div id="auth-error" class="text-red-400 text-sm text-center hidden"></div>
                    </div>
                </div>
                
                <div id="signup-form" class="hidden">
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium mb-2">Email</label>
                            <input type="email" id="signup-email" 
                                   class="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                   placeholder="you@example.com">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium mb-2">Password</label>
                            <input type="password" id="signup-password" 
                                   class="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                   placeholder="••••••••">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium mb-2">Confirm Password</label>
                            <input type="password" id="signup-confirm" 
                                   class="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                   placeholder="••••••••">
                        </div>
                        
                        <button onclick="window.handleSignup()" 
                                class="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-4 rounded-lg transition duration-200">
                            <i class="fas fa-user-plus mr-2"></i> Create Account
                        </button>
                        
                        <div class="text-center">
                            <p class="text-gray-400">Already have an account? 
                                <button onclick="window.showLogin()" class="text-blue-400 hover:text-blue-300 font-medium">
                                    Login here
                                </button>
                            </p>
                        </div>
                        
                        <div id="signup-error" class="text-red-400 text-sm text-center hidden"></div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Make functions available globally
    window.handleLogin = handleLogin;
    window.handleSignup = handleSignup;
    window.showSignup = showSignup;
    window.showLogin = showLogin;
}

function renderDashboard() {
    const app = document.getElementById('app');
    app.innerHTML = `
        <!-- Header -->
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
            <div>
                <h1 class="text-3xl font-bold flex items-center">
                    <i class="fas fa-robot text-blue-500 mr-3"></i>
                    Bot Dashboard
                </h1>
                <p class="text-gray-400 mt-1">Welcome, ${currentUser.email}</p>
            </div>
            
            <div class="flex items-center space-x-4">
                <div id="status-container" class="flex items-center px-4 py-2 bg-gray-800 rounded-lg">
                    <span class="status-dot status-${botStatus}"></span>
                    <span id="status-text" class="font-medium">${botStatus.charAt(0).toUpperCase() + botStatus.slice(1)}</span>
                </div>
                
                <button onclick="window.handleLogout()" 
                        class="flex items-center px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg transition duration-200">
                    <i class="fas fa-sign-out-alt mr-2"></i> Logout
                </button>
            </div>
        </div>
        
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Left Column -->
            <div class="lg:col-span-2 space-y-6">
                <!-- File Upload Section -->
                <div class="bg-gray-800 rounded-xl shadow-lg p-6">
                    <h2 class="text-xl font-bold mb-4 flex items-center">
                        <i class="fas fa-file-upload text-blue-400 mr-2"></i>
                        Upload Bot Files
                    </h2>
                    
                    <div id="file-upload-area" class="file-upload-area p-8 text-center rounded-lg cursor-pointer mb-6">
                        <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-4"></i>
                        <p class="text-gray-300 mb-2">Drag & drop your bot.py and requirements.txt here</p>
                        <p class="text-gray-400 text-sm">Or click to select files</p>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <input type="file" id="bot-file" accept=".py" class="hidden">
                            <label for="bot-file" class="block p-4 bg-gray-700 hover:bg-gray-600 rounded-lg cursor-pointer transition duration-200">
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center">
                                        <i class="fas fa-file-code text-blue-400 text-xl mr-3"></i>
                                        <span class="font-medium">bot.py</span>
                                    </div>
                                    <span id="bot-file-status" class="text-gray-400">${botFiles.bot ? 'Uploaded' : 'Not uploaded'}</span>
                                </div>
                                ${botFiles.bot ? `
                                <div class="text-sm text-gray-400 mt-2">
                                    ${botFiles.bot.name} (${formatFileSize(botFiles.bot.size)})
                                </div>
                                ` : ''}
                            </label>
                        </div>
                        
                        <div>
                            <input type="file" id="req-file" accept=".txt" class="hidden">
                            <label for="req-file" class="block p-4 bg-gray-700 hover:bg-gray-600 rounded-lg cursor-pointer transition duration-200">
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center">
                                        <i class="fas fa-file-alt text-green-400 text-xl mr-3"></i>
                                        <span class="font-medium">requirements.txt</span>
                                    </div>
                                    <span id="req-file-status" class="text-gray-400">${botFiles.req ? 'Uploaded' : 'Not uploaded'}</span>
                                </div>
                                ${botFiles.req ? `
                                <div class="text-sm text-gray-400 mt-2">
                                    ${botFiles.req.name} (${formatFileSize(botFiles.req.size)})
                                </div>
                                ` : ''}
                            </label>
                        </div>
                    </div>
                </div>
                
                <!-- Console Output -->
                <div class="bg-gray-800 rounded-xl shadow-lg p-6">
                    <div class="flex justify-between items-center mb-4">
                        <h2 class="text-xl font-bold flex items-center">
                            <i class="fas fa-terminal text-green-400 mr-2"></i>
                            Live Console
                        </h2>
                        <div class="flex space-x-2">
                            <button onclick="window.clearConsole()" 
                                    class="px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-sm transition duration-200">
                                <i class="fas fa-trash mr-1"></i> Clear
                            </button>
                            <button onclick="window.refreshLogs()" 
                                    class="px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-sm transition duration-200">
                                <i class="fas fa-sync-alt mr-1"></i> Refresh
                            </button>
                        </div>
                    </div>
                    
                    <div id="console" class="console rounded-lg p-4 h-80 overflow-y-auto">
                        <div class="log-info">[System] Welcome to Python Bot Hosting Platform</div>
                        <div class="log-info">[System] Upload your bot files and click Deploy to Netlify</div>
                    </div>
                </div>
            </div>
            
            <!-- Right Column -->
            <div class="space-y-6">
                <!-- Bot Controls -->
                <div class="bg-gray-800 rounded-xl shadow-lg p-6">
                    <h2 class="text-xl font-bold mb-4 flex items-center">
                        <i class="fas fa-play-circle text-green-400 mr-2"></i>
                        Bot Controls
                    </h2>
                    
                    <div class="space-y-4">
                        <button id="deploy-btn" onclick="window.deployToNetlify()" 
                                class="w-full flex items-center justify-center py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 rounded-lg font-semibold transition duration-200">
                            <i class="fas fa-rocket mr-2"></i>
                            <span>Deploy to Netlify</span>
                            <span id="deploy-spinner" class="ml-2 hidden">
                                <div class="loading-spinner"></div>
                            </span>
                        </button>
                        
                        <button id="start-btn" onclick="window.startBot()" ${botStatus === 'running' ? 'disabled' : ''}
                                class="w-full flex items-center justify-center py-3 bg-green-600 hover:bg-green-700 rounded-lg font-semibold transition duration-200">
                            <i class="fas fa-play mr-2"></i>
                            Start Bot
                        </button>
                        
                        <button id="stop-btn" onclick="window.stopBot()" ${botStatus !== 'running' ? 'disabled' : ''}
                                class="w-full flex items-center justify-center py-3 bg-red-600 hover:bg-red-700 rounded-lg font-semibold transition duration-200">
                            <i class="fas fa-stop mr-2"></i>
                            Stop Bot
                        </button>
                        
                        <button onclick="window.updateFiles()" 
                                class="w-full flex items-center justify-center py-3 bg-yellow-600 hover:bg-yellow-700 rounded-lg font-semibold transition duration-200">
                            <i class="fas fa-sync-alt mr-2"></i>
                            Update Files
                        </button>
                    </div>
                    
                    <div class="mt-6 pt-6 border-t border-gray-700">
                        <h3 class="font-medium mb-3">Deployment Info</h3>
                        ${userData?.netlifyUrl ? `
                        <a href="${userData.netlifyUrl}" target="_blank" 
                           class="flex items-center p-3 bg-gray-700 hover:bg-gray-600 rounded transition duration-200">
                            <i class="fas fa-external-link-alt text-blue-400 mr-3"></i>
                            <div class="truncate">
                                <div class="text-sm text-gray-400">Your Bot URL</div>
                                <div class="truncate">${userData.netlifyUrl}</div>
                            </div>
                        </a>
                        ` : `
                        <div class="p-3 bg-gray-700 rounded">
                            <div class="flex items-center">
                                <i class="fas fa-info-circle text-yellow-400 mr-3"></i>
                                <div>
                                    <div class="text-sm">Deploy to get your bot URL</div>
                                </div>
                            </div>
                        </div>
                        `}
                    </div>
                </div>
                
                <!-- Bot Info -->
                <div class="bg-gray-800 rounded-xl shadow-lg p-6">
                    <h2 class="text-xl font-bold mb-4 flex items-center">
                        <i class="fas fa-info-circle text-blue-400 mr-2"></i>
                        Bot Information
                    </h2>
                    
                    <div class="space-y-4">
                        <div class="p-3 bg-gray-700 rounded">
                            <div class="text-sm text-gray-400">Balance</div>
                            <div class="text-xl font-bold">$<span id="balance">${userData?.balance?.toFixed(2) || '100.00'}</span></div>
                        </div>
                        
                        <div class="p-3 bg-gray-700 rounded">
                            <div class="text-sm text-gray-400">Last Deployed</div>
                            <div id="last-deployed">${userData?.lastDeployed ? new Date(userData.lastDeployed.seconds * 1000).toLocaleString() : 'Never'}</div>
                        </div>
                        
                        <div class="p-3 bg-gray-700 rounded">
                            <div class="text-sm text-gray-400">Status</div>
                            <div class="flex items-center">
                                <span class="status-dot status-${botStatus} mr-2"></span>
                                <span id="status-display">${botStatus.charAt(0).toUpperCase() + botStatus.slice(1)}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Make functions available globally
    window.handleLogout = handleLogout;
    window.deployToNetlify = deployToNetlify;
    window.startBot = startBot;
    window.stopBot = stopBot;
    window.updateFiles = updateFiles;
    window.clearConsole = clearConsole;
    window.refreshLogs = refreshLogs;
    
    // Setup file upload handlers
    setupFileUploads();
}

// Auth Functions
async function handleLogin() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const errorEl = document.getElementById('auth-error');
    
    if (!email || !password) {
        errorEl.textContent = 'Please fill in all fields';
        errorEl.classList.remove('hidden');
        return;
    }
    
    try {
        await firebase.signInWithEmailAndPassword(auth, email, password);
        errorEl.classList.add('hidden');
    } catch (error) {
        errorEl.textContent = error.message;
        errorEl.classList.remove('hidden');
    }
}

async function handleSignup() {
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;
    const confirm = document.getElementById('signup-confirm').value;
    const errorEl = document.getElementById('signup-error');
    
    if (!email || !password || !confirm) {
        errorEl.textContent = 'Please fill in all fields';
        errorEl.classList.remove('hidden');
        return;
    }
    
    if (password !== confirm) {
        errorEl.textContent = 'Passwords do not match';
        errorEl.classList.remove('hidden');
        return;
    }
    
    if (password.length < 6) {
        errorEl.textContent = 'Password must be at least 6 characters';
        errorEl.classList.remove('hidden');
        return;
    }
    
    try {
        const userCredential = await firebase.createUserWithEmailAndPassword(auth, email, password);
        
        // Create user document
        await firebase.setDoc(firebase.doc(db, 'users', userCredential.user.uid), {
            email: email,
            balance: 100.00,
            createdAt: firebase.serverTimestamp(),
            botState: 'stopped',
            botFiles: {},
            lastDeployed: null,
            netlifyUrl: null,
            githubRepo: null
        });
        
        errorEl.classList.add('hidden');
        showLogin();
    } catch (error) {
        errorEl.textContent = error.message;
        errorEl.classList.remove('hidden');
    }
}

function showSignup() {
    document.getElementById('login-form').classList.add('hidden');
    document.getElementById('signup-form').classList.remove('hidden');
}

function showLogin() {
    document.getElementById('signup-form').classList.add('hidden');
    document.getElementById('login-form').classList.remove('hidden');
}

async function handleLogout() {
    try {
        await firebase.signOut(auth);
    } catch (error) {
        console.error('Logout error:', error);
    }
}

// File Upload Functions
function setupFileUploads() {
    const uploadArea = document.getElementById('file-upload-area');
    const botFileInput = document.getElementById('bot-file');
    const reqFileInput = document.getElementById('req-file');
    
    if (!uploadArea) return;
    
    // Click handler for upload area
    uploadArea.addEventListener('click', () => {
        botFileInput.click();
    });
    
    // Bot file change handler
    botFileInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (file && file.name.endsWith('.py')) {
            await handleFileUpload(file, 'bot');
        }
    });
    
    // Requirements file change handler
    reqFileInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (file && (file.name.endsWith('.txt') || file.name === 'requirements.txt')) {
            await handleFileUpload(file, 'req');
        }
    });
    
    // Drag and drop functionality
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    ['dragenter', 'dragover'].forEach(eventName => {
        uploadArea.addEventListener(eventName, () => {
            uploadArea.classList.add('drag-over');
        });
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, () => {
            uploadArea.classList.remove('drag-over');
        });
    });
    
    // Handle drop
    uploadArea.addEventListener('drop', async (e) => {
        const dt = e.dataTransfer;
        const files = dt.files;
        
        for (let file of files) {
            if (file.name.endsWith('.py')) {
                await handleFileUpload(file, 'bot');
            } else if (file.name.endsWith('.txt') || file.name === 'requirements.txt') {
                await handleFileUpload(file, 'req');
            }
        }
    });
}

async function handleFileUpload(file, type) {
    const reader = new FileReader();
    
    reader.onload = async (e) => {
        const content = e.target.result;
        
        botFiles[type] = {
            name: file.name,
            content: content,
            size: file.size,
            lastModified: new Date().toISOString()
        };
        
        // Update UI
        updateFileDisplay(type);
        
        // Save to Firestore
        try {
            await firebase.updateDoc(firebase.doc(db, 'users', currentUser.uid), {
                [`botFiles.${type}`]: botFiles[type]
            });
            
            addToConsole(`✓ Uploaded ${file.name} (${formatFileSize(file.size)})`, 'success');
        } catch (error) {
            addToConsole(`Error saving file: ${error.message}`, 'error');
        }
    };
    
    reader.readAsText(file);
}

function updateFileDisplay(type) {
    const statusEl = document.getElementById(`${type}-file-status`);
    const file = botFiles[type];
    
    if (statusEl) {
        statusEl.textContent = 'Uploaded';
        statusEl.className = 'text-green-400';
    }
    
    // Refresh the dashboard to show updated files
    renderDashboard();
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Bot Control Functions
async function deployToNetlify() {
    if (!botFiles.bot) {
        addToConsole('Error: Please upload bot.py first', 'error');
        return;
    }
    
    const deployBtn = document.getElementById('deploy-btn');
    const spinner = document.getElementById('deploy-spinner');
    
    deployBtn.disabled = true;
    spinner.classList.remove('hidden');
    
    addToConsole('Starting deployment to Netlify...', 'info');
    updateStatus('deploying');
    
    try {
        // Call Netlify function for deployment
        const response = await fetch('/.netlify/functions/deploy', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${await currentUser.getIdToken()}`
            },
            body: JSON.stringify({
                userId: currentUser.uid,
                email: currentUser.email,
                files: botFiles,
                githubToken: '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'
            })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Deployment failed');
        }
        
        // Update user data with deployment info
        await firebase.updateDoc(firebase.doc(db, 'users', currentUser.uid), {
            netlifyUrl: data.netlifyUrl,
            githubRepo: data.githubRepo,
            lastDeployed: firebase.serverTimestamp(),
            deploymentId: data.deploymentId
        });
        
        addToConsole(`✓ Deployment successful!`, 'success');
        addToConsole(`Bot URL: ${data.netlifyUrl}`, 'info');
        addToConsole(`GitHub Repo: ${data.githubRepo}`, 'info');
        
        updateStatus('stopped');
        
    } catch (error) {
        addToConsole(`Deployment error: ${error.message}`, 'error');
        updateStatus('error');
    } finally {
        deployBtn.disabled = false;
        spinner.classList.add('hidden');
    }
}

async function startBot() {
    addToConsole('Starting bot...', 'info');
    updateStatus('running');
    
    try {
        await firebase.updateDoc(firebase.doc(db, 'users', currentUser.uid), {
            botState: 'running'
        });
        
        addToConsole('✓ Bot started successfully', 'success');
        
        // Simulate bot activity
        simulateBotActivity();
        
    } catch (error) {
        addToConsole(`Error starting bot: ${error.message}`, 'error');
        updateStatus('error');
    }
}

async function stopBot() {
    addToConsole('Stopping bot...', 'warning');
    updateStatus('stopped');
    
    try {
        await firebase.updateDoc(firebase.doc(db, 'users', currentUser.uid), {
            botState: 'stopped'
        });
        
        addToConsole('✓ Bot stopped', 'info');
    } catch (error) {
        addToConsole(`Error stopping bot: ${error.message}`, 'error');
    }
}

async function updateFiles() {
    if (!botFiles.bot && !botFiles.req) {
        addToConsole('Error: No files to update', 'error');
        return;
    }
    
    addToConsole('Updating bot files...', 'info');
    
    try {
        await firebase.updateDoc(firebase.doc(db, 'users', currentUser.uid), {
            botFiles: botFiles
        });
        
        addToConsole('✓ Files updated successfully', 'success');
    } catch (error) {
        addToConsole(`Error updating files: ${error.message}`, 'error');
    }
}

function simulateBotActivity() {
    // Simulate bot logs
    const activities = [
        'Bot initialized',
        'Loading configuration...',
        'Connecting to database...',
        'Starting main loop...',
        'Processing task #1...',
        'Task completed successfully'
    ];
    
    let i = 0;
    const interval = setInterval(() => {
        if (botStatus !== 'running') {
            clearInterval(interval);
            return;
        }
        
        if (i < activities.length) {
            addToConsole(activities[i], 'info');
            i++;
        } else {
            // Simulate ongoing activity
            const ongoing = [
                'Processing data...',
                'API request completed',
                'Database updated',
                'Sleeping for 5 seconds...'
            ];
            const randomMsg = ongoing[Math.floor(Math.random() * ongoing.length)];
            addToConsole(randomMsg, 'info');
        }
    }, 3000);
}

// Status Management
function updateStatus(status) {
    botStatus = status;
    
    const statusContainer = document.getElementById('status-container');
    const statusText = document.getElementById('status-text');
    const statusDisplay = document.getElementById('status-display');
    const startBtn = document.getElementById('start-btn');
    const stopBtn = document.getElementById('stop-btn');
    
    if (statusContainer) {
        statusContainer.querySelector('.status-dot').className = `status-dot status-${status}`;
        statusText.textContent = status.charAt(0).toUpperCase() + status.slice(1);
    }
    
    if (statusDisplay) {
        statusDisplay.textContent = status.charAt(0).toUpperCase() + status.slice(1);
    }
    
    if (startBtn) startBtn.disabled = status === 'running';
    if (stopBtn) stopBtn.disabled = status !== 'running';
}

// Console Functions
function addToConsole(message, type = 'info') {
    const consoleEl = document.getElementById('console');
    if (!consoleEl) return;
    
    const timestamp = new Date().toLocaleTimeString();
    const logLine = document.createElement('div');
    logLine.className = `log-${type}`;
    logLine.textContent = `[${timestamp}] ${message}`;
    
    consoleEl.appendChild(logLine);
    consoleEl.scrollTop = consoleEl.scrollHeight;
}

function clearConsole() {
    const consoleEl = document.getElementById('console');
    if (consoleEl) {
        consoleEl.innerHTML = `
            <div class="log-info">[System] Console cleared at ${new Date().toLocaleTimeString()}</div>
            <div class="log-info">[System] Ready for new logs</div>
        `;
    }
}

function refreshLogs() {
    addToConsole('Refreshing logs...', 'info');
}

// Realtime Listener
function setupRealtimeListener() {
    if (!currentUser) return;
    
    firebase.onSnapshot(firebase.doc(db, 'users', currentUser.uid), (doc) => {
        if (doc.exists()) {
            const data = doc.data();
            userData = data;
            
            // Update status if changed
            if (data.botState && data.botState !== botStatus) {
                botStatus = data.botState;
                updateStatus(botStatus);
            }
            
            // Update bot files if changed
            if (data.botFiles) {
                botFiles = data.botFiles;
            }
            
            // Update UI elements
            const balanceEl = document.getElementById('balance');
            const lastDeployedEl = document.getElementById('last-deployed');
            
            if (balanceEl && data.balance) {
                balanceEl.textContent = data.balance.toFixed(2);
            }
            
            if (lastDeployedEl && data.lastDeployed) {
                const date = data.lastDeployed.toDate ? 
                    data.lastDeployed.toDate() : 
                    new Date(data.lastDeployed.seconds * 1000);
                lastDeployedEl.textContent = date.toLocaleString();
            }
        }
    });
}