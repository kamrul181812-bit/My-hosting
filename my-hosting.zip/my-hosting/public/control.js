// control.js - Additional control functions

// This file can be used for additional bot control logic
// Currently all functions are in app.js

console.log('Control module loaded');