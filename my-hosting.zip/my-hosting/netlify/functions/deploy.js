const { Octokit } = require("@octokit/rest");
const axios = require("axios");
const admin = require("firebase-admin");

// Initialize Firebase Admin
if (!admin.apps.length) {
  try {
    admin.initializeApp({
      credential: admin.credential.cert({
        project_id: process.env.FIREBASE_PROJECT_ID,
        private_key: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
        client_email: process.env.FIREBASE_CLIENT_EMAIL
      })
    });
    console.log("Firebase Admin initialized successfully");
  } catch (error) {
    console.error("Firebase Admin initialization error:", error.message);
  }
}

exports.handler = async (event, context) => {
  console.log("Deploy function called");
  
  // Handle CORS
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Allow-Methods': 'POST, OPTIONS'
      },
      body: ''
    };
  }

  // Only allow POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    const data = JSON.parse(event.body);
    const { userId, email, files } = data;
    
    console.log("Deployment request for user:", userId);

    if (!userId || !files || !files.bot) {
      return {
        statusCode: 400,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: 'Missing bot.py file' })
      };
    }

    // Verify Firebase token
    const authHeader = event.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return {
        statusCode: 401,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: 'No authorization token' })
      };
    }

    const token = authHeader.split('Bearer ')[1];
    let decodedToken;
    try {
      decodedToken = await admin.auth().verifyIdToken(token);
      console.log("Token verified for user:", decodedToken.uid);
    } catch (error) {
      console.error("Token verification failed:", error.message);
      return {
        statusCode: 401,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: 'Invalid token: ' + error.message })
      };
    }

    if (decodedToken.uid !== userId) {
      return {
        statusCode: 403,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: 'User ID mismatch' })
      };
    }

    // Initialize GitHub client
    const octokit = new Octokit({
      auth: process.env.GITHUB_TOKEN
    });

    // Get GitHub user info
    let githubUser;
    try {
      const response = await octokit.users.getAuthenticated();
      githubUser = response.data;
      console.log("GitHub user:", githubUser.login);
    } catch (error) {
      console.error("GitHub auth failed:", error.message);
      return {
        statusCode: 500,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: 'GitHub authentication failed' })
      };
    }

    // Create repo name
    const repoName = `bot-${userId.substring(0, 8)}-${Date.now().toString(36)}`;
    console.log("Creating repo:", repoName);

    // Create GitHub repository
    let repo;
    try {
      repo = await octokit.repos.createForAuthenticatedUser({
        name: repoName,
        private: true,
        auto_init: false,
        description: `Python bot for ${email}`
      });
      console.log("Repo created:", repo.data.html_url);
    } catch (error) {
      console.error("Repo creation failed:", error.message);
      return {
        statusCode: 500,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: 'Failed to create GitHub repository' })
      };
    }

    // Upload bot.py
    try {
      await octokit.repos.createOrUpdateFileContents({
        owner: githubUser.login,
        repo: repoName,
        path: 'bot.py',
        message: 'Add bot.py',
        content: Buffer.from(files.bot.content).toString('base64'),
        committer: {
          name: 'Bot Hosting Platform',
          email: 'bot@platform.com'
        }
      });
      console.log("bot.py uploaded");
    } catch (error) {
      console.error("Failed to upload bot.py:", error.message);
    }

    // Upload requirements.txt
    try {
      const requirementsContent = files.req ? files.req.content : '# Python dependencies\nrequests==2.31.0\n';
      await octokit.repos.createOrUpdateFileContents({
        owner: githubUser.login,
        repo: repoName,
        path: 'requirements.txt',
        message: 'Add requirements.txt',
        content: Buffer.from(requirementsContent).toString('base64'),
        committer: {
          name: 'Bot Hosting Platform',
          email: 'bot@platform.com'
        }
      });
      console.log("requirements.txt uploaded");
    } catch (error) {
      console.error("Failed to upload requirements.txt:", error.message);
    }

    // Create netlify.toml
    const netlifyConfig = `[build]
  publish = "."
  command = "python bot.py"

[[plugins]]
  package = "@netlify/plugin-python"

[build.environment]
  PYTHON_VERSION = "3.9"`;

    try {
      await octokit.repos.createOrUpdateFileContents({
        owner: githubUser.login,
        repo: repoName,
        path: 'netlify.toml',
        message: 'Add Netlify config',
        content: Buffer.from(netlifyConfig).toString('base64'),
        committer: {
          name: 'Bot Hosting Platform',
          email: 'bot@platform.com'
        }
      });
      console.log("netlify.toml uploaded");
    } catch (error) {
      console.error("Failed to upload netlify.toml:", error.message);
    }

    // Deploy to Netlify
    let netlifyResponse;
    try {
      console.log("Deploying to Netlify...");
      netlifyResponse = await axios.post(
        'https://api.netlify.com/api/v1/sites',
        {
          name: repoName,
          repo: {
            provider: 'github',
            repo: repoName,
            repo_path: `${githubUser.login}/${repoName}`,
            branch: 'main',
            dir: '.'
          }
        },
        {
          headers: {
            'Authorization': `Bearer ${process.env.NETLIFY_TOKEN}`,
            'Content-Type': 'application/json'
          },
          timeout: 30000
        }
      );
      console.log("Netlify deployment successful:", netlifyResponse.data.ssl_url);
    } catch (error) {
      console.error("Netlify deployment failed:", error.message);
      if (error.response) {
        console.error("Response data:", error.response.data);
        console.error("Response status:", error.response.status);
      }
      return {
        statusCode: 500,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ 
          error: 'Netlify deployment failed',
          details: error.message 
        })
      };
    }

    // Update Firestore
    try {
      const db = admin.firestore();
      await db.collection('users').doc(userId).update({
        githubRepo: repo.data.full_name,
        netlifyUrl: netlifyResponse.data.ssl_url || netlifyResponse.data.url,
        lastDeployed: admin.firestore.FieldValue.serverTimestamp(),
        botState: 'stopped'
      });
      console.log("Firestore updated");
    } catch (error) {
      console.error("Firestore update failed:", error.message);
    }

    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        success: true,
        githubRepo: repo.data.full_name,
        netlifyUrl: netlifyResponse.data.ssl_url || netlifyResponse.data.url,
        deploymentId: netlifyResponse.data.site_id,
        message: 'Deployment successful!'
      })
    };

  } catch (error) {
    console.error("Unexpected error in deploy function:", error);
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ 
        error: 'Deployment failed',
        details: error.message 
      })
    };
  }
};